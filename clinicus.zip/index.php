<?php

require_once "./Controllers/HomeController.php";

$controller = new HomeController();
$controller->index();