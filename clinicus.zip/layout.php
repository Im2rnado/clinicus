<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinicus - <?php echo $title ?? 'Medical Center'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/clinicus/">Clinicus</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/clinicus/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/clinicus/#services">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/clinicus/#doctors">Doctors</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/clinicus/admin/">Admin Panel</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container my-4">
        <?php echo $content ?? ''; ?>
    </main>

    <footer class="bg-light py-3 mt-auto">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y'); ?> Clinicus. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>